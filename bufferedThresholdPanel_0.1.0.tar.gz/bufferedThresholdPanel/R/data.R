#' Panel Data on Economic Growth, Oil Dependence, and Economic Complexity
#'
#' A balanced panel of 92 developed and developing countries observed annually
#' from 2002 to 2016 (1 380 observations).  The dataset is used in Hamdi,
#' Souam, and Zouikri (2025) to estimate the heterogeneous effect of economic
#' complexity on GDP growth and human development using the Buffered Panel
#' Threshold Data (BTPD) model of Belarbi et al. (2021).
#'
#' @format A data frame with 1 380 rows and 14 columns:
#' \describe{
#'   \item{countryId}{Integer country identifier (1–92, alphabetical order)}
#'   \item{country}{Country name (character)}
#'   \item{year}{Calendar year (integer, 2002–2016)}
#'   \item{growthRate}{Annual GDP growth rate, computed as the first logarithmic
#'     difference of real GDP per capita in constant prices.
#'     Mean 0.024, SD 0.038, range \[−0.376, 0.218\].
#'     \emph{Dependent variable.}}
#'   \item{oilRentGDP}{Oil rents as a percentage of GDP: the difference between
#'     the value of crude oil production at world prices and total production
#'     costs, expressed as a share of GDP.
#'     Mean 3.36, SD 8.85, range \[0, 59.2\].
#'     \emph{Threshold variable in Model I (oil dependence); predictor in
#'     Model II (institutions).}}
#'   \item{rle}{Rule of Law index from the World Bank Worldwide Governance
#'     Indicators (WGI).  Captures perceptions of the extent to which agents
#'     have confidence in and abide by the rules of society, including the
#'     quality of contract enforcement, property rights, the police, and the
#'     courts, as well as the likelihood of crime and violence.  Rescaled to
#'     the unit interval \[0, 1\], where higher values indicate stronger rule
#'     of law.  Mean 0.500, SD 0.257, range \[0, 1\].
#'     \emph{Threshold variable in Model II (institutions); predictor in
#'     Model I (oil dependence).}}
#'   \item{initialGDP}{Log of initial real GDP per capita in PPP (constant
#'     international dollars).  Following Barro (2003), the initial value
#'     retained for each five-year sub-period is that of the first year of
#'     the sub-period.  Mean 9.35, SD 1.12.}
#'   \item{eci}{Economic Complexity Index (ECI) from the Atlas of Economic
#'     Complexity (Harvard CID).  Measures the composition of a country's
#'     productive output and the knowledge embedded in its export structure.
#'     Mean 0.53, SD 0.20, range \[0, 1\].}
#'   \item{fdiGDP}{Net inflows of Foreign Direct Investment as a percentage of
#'     GDP (current US dollars).  Mean 5.05, SD 9.96.}
#'   \item{capFormGDP}{Gross fixed capital formation (domestic investment) as
#'     a percentage of GDP.  Mean 22.8, SD 5.64.}
#'   \item{inflation}{Inflation rate measured as the annual growth rate of the
#'     GDP implicit deflator.  Mean 6.11, SD 9.98.}
#'   \item{popGrowth}{Annual population growth rate (percentage).
#'     Mean 1.23, SD 1.38.}
#'   \item{indVAGDP}{Manufacturing (industrial) value added as a percentage of
#'     GDP (ISIC divisions 15–37).  Mean 15.0, SD 6.41.}
#'   \item{tradeOpenness}{Trade openness: sum of exports and imports of goods
#'     and services divided by real GDP.  Mean 88.4, SD 49.4.}
#' }
#'
#' @details
#' The panel is perfectly balanced (no missing values).  Data come from
#' multiple sources:
#' \itemize{
#'   \item GDP growth, initial GDP, FDI, capital formation, inflation,
#'     population growth, industrial value added, and trade openness:
#'     World Development Indicators (WDI), World Bank.
#'   \item Oil rents: WDI, World Bank.
#'   \item Economic Complexity Index: Atlas of Economic Complexity,
#'     Center for International Development, Harvard University.
#' }
#'
#' The 92 countries span all income groups and geographic regions.  See
#' Table A1 in Hamdi et al. (2025) for the full country list.
#'
#' @source
#' World Bank World Development Indicators
#' (\url{https://databank.worldbank.org/source/world-development-indicators});
#' Harvard CID Atlas of Economic Complexity
#' (\url{https://atlas.cid.harvard.edu}).
#'
#' @references
#' Hamdi, F., Souam, S., and Zouikri, M. (2025).
#' The heterogeneous effect of economic complexity on growth and human
#' development: New empirical evidence using buffered panel threshold
#' regression.
#' \emph{The World Economy}, 48, 2561--2592.
#' \doi{10.1111/twec.70023}
#'
#' Belarbi, Y., Hamdi, F., Khalfi, A., and Souam, S. (2021).
#' Growth, institutions and oil dependence: A buffered threshold panel
#' approach.
#' \emph{Economic Modelling}, 99, 105477.
#' \doi{10.1016/j.econmod.2021.02.018}
#'
#' Barro, R. J. (2003).
#' Determinants of economic growth in a panel of countries.
#' \emph{Annals of Economics and Finance}, 4(2), 231--274.
#'
#' @examples
#' data(panel_data)
#' head(panel_data)
#'
#' # Basic panel structure
#' cat("Countries:", length(unique(panel_data$country)), "\n")
#' cat("Years    :", length(unique(panel_data$year)), "\n")
#' cat("Obs      :", nrow(panel_data), "\n")
#'
#' # Summary of key variables
#' summary(panel_data[, c("growthRate", "oilRentGDP", "eci")])
"panel_data"
