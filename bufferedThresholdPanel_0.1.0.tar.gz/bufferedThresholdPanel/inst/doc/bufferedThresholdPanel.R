## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse  = TRUE,
  comment   = "#>",
  fig.width = 6,
  fig.height = 3.5
)

## ----install, eval=FALSE------------------------------------------------------
# # From CRAN (once published)
# install.packages("bufferedThresholdPanel")
# 
# # Development version
# remotes::install_github("MessaoudZouikri/bufferedThresholdPanel")

## ----load---------------------------------------------------------------------
library(bufferedThresholdPanel)

## ----simulate-----------------------------------------------------------------
set.seed(42)
N  <- 30   # cross-sectional units
TT <- 10   # time periods

df_sim <- data.frame(
  id   = rep(seq_len(N), each = TT),
  time = rep(seq_len(TT), N),
  x1   = rnorm(N * TT),
  x2   = rnorm(N * TT),
  q    = rnorm(N * TT)           # threshold variable
)

# True DGP: two regimes separated at q = 0.4
#   Regime 1 (q <= 0.4):  y = 1.5*x1 - 0.5*x2 + e
#   Regime 2 (q >  0.4):  y = -0.5*x1 + 1.0*x2 + e
df_sim$y <- with(df_sim,
  ifelse(q <= 0.4,
         1.5 * x1 - 0.5 * x2,
        -0.5 * x1 + 1.0 * x2) + rnorm(N * TT, 0, 0.5)
)

## ----fit2---------------------------------------------------------------------
fit2 <- bptr(
  y ~ x1 + x2,
  data     = df_sim,
  id       = "id",
  time     = "time",
  q        = "q",
  n_thresh = 1,          # 1 threshold → 2 regimes
  buffer   = TRUE,       # BTPD (hysteresis) transitions
  se_type  = "HC3"
)
print(fit2)

## ----fit2_summary-------------------------------------------------------------
summary(fit2)

## ----extractors---------------------------------------------------------------
# Coefficient matrix (variables × regimes)
round(coef(fit2), 4)

# Number of regimes in the fitted object
fit2$n_regimes          # 2 for n_thresh=1; 3 for n_thresh=2

# Number of observations per regime
fit2$n_obs_regime

# Within R-squared
round(1 - fit2$ssr / fit2$tss_within, 4)

# Threshold / buffer-zone boundaries  [rL, rU]
round(fit2$thresholds, 4)

# Variance-covariance matrix (block-diagonal by regime)
round(vcov(fit2), 6)

# In-sample prediction (identical to fitted values)
head(round(predict(fit2), 4))

## ----fit3---------------------------------------------------------------------
fit3 <- bptr(
  y ~ x1 + x2,
  data        = df_sim,
  id          = "id",
  time        = "time",
  q           = "q",
  n_thresh    = 2,        # 2 thresholds → 3 regimes
  buffer      = TRUE,
  grid_size_3 = 10,       # ⚠ illustration only — use >= 50 for real analyses
  se_type     = "HC3"
)
summary(fit3)

## ----fit3_zones---------------------------------------------------------------
# Confirm 3 regimes are stored
fit3$n_regimes                               # should be 3
cat("Buffer zone 1 : [", round(fit3$thresholds[1], 4),
    ",", round(fit3$thresholds[2], 4), "]\n")
cat("Buffer zone 2 : [", round(fit3$thresholds[3], 4),
    ",", round(fit3$thresholds[4], 4), "]\n")
cat("Regime sizes  :", paste(fit3$n_obs_regime, collapse = " / "), "\n")

## ----fit_ptr------------------------------------------------------------------
fit_ptr <- bptr(
  y ~ x1 + x2,
  data     = df_sim,
  id       = "id",
  time     = "time",
  q        = "q",
  n_thresh = 1,
  buffer   = FALSE        # abrupt transition (Hansen 1999)
)
cat("PTR threshold :", round(fit_ptr$thresholds, 4), "\n")
cat("BTPD zone     : [", round(fit2$thresholds, 4), "]\n")

## ----tidy---------------------------------------------------------------------
library(broom)

# Coefficient table with 95% confidence intervals
tidy(fit2, conf.int = TRUE)

## ----glance-------------------------------------------------------------------
# Model-level fit statistics
glance(fit2)

## ----threshold_tidy-----------------------------------------------------------
# Threshold / buffer-zone estimates
threshold_tidy(fit2)

## ----augment------------------------------------------------------------------
# Add fitted values and regime classification to the data frame
aug <- augment(fit2)
head(aug[, c("id", "time", "q", "y", ".fitted", ".resid", ".regime")])

## ----plot1, fig.height=3.5----------------------------------------------------
# Residuals vs fitted, coloured by regime
plot(fit2, which = 1)

## ----plot2, fig.height=3.5----------------------------------------------------
# Threshold variable with buffer-zone boundaries
plot(fit2, which = 2)

## ----kable--------------------------------------------------------------------
# knitr::kable for R Markdown documents
bptr_kable(fit2, digits = 3)

## ----table_aer, eval=FALSE----------------------------------------------------
# # American Economic Review style (requires gt)
# bptr_table(fit2, style = "AER", stars = TRUE,
#            title = "Two-Regime BTPD Estimation")
# 
# # LaTeX export for inclusion in a paper
# bptr_latex(fit2, file = "table_btpd.tex")

## ----seq_test, eval=FALSE-----------------------------------------------------
# # ── F1,2: linearity vs 2-regime BTPD ──────────────────────────────────────
# test12 <- bptr_test(
#   y ~ x1 + x2, data = df_sim,
#   id = "id", time = "time", q = "q",
#   buffer = TRUE, n_boot = 499, seed = 42
# )
# print(test12)      # class "bptr_test"
# 
# # ── F1,2 for classical PTR (buffer = FALSE) ────────────────────────────────
# test12_ptr <- bptr_test(
#   y ~ x1 + x2, data = df_sim,
#   id = "id", time = "time", q = "q",
#   buffer = FALSE, n_boot = 499, seed = 42
# )
# print(test12_ptr)
# 
# # ── F2,3: 2-regime vs 3-regime (takes a fitted bptr object as H0) ──────────
# # Note: first argument is the fitted 2-regime model, NOT a formula
# test23 <- bptr_test_23(fit2, n_boot = 499, grid_size_3 = 50, seed = 42)
# print(test23)      # class "bptr_test23" — different print method from test12
# 
# # ── Complete sequential procedure (F1,2 → F2,3 → model selection) ──────────
# # bptr_test_seq() prints progress via cat() as each step completes
# result_seq <- bptr_test_seq(
#   y ~ x1 + x2, data = df_sim,
#   id = "id", time = "time", q = "q",
#   buffer = TRUE, n_boot = 499, alpha = 0.10, seed = 42
# )
# print(result_seq)
# # $n_regimes_selected reports 1, 2, or 3
# # $final_model is the recommended fitted bptr object

## ----bootstrap_ci, eval=FALSE-------------------------------------------------
# # Residual bootstrap for the 2-regime BTPD model (parallel on all cores - 1)
# boot <- bptr_bootstrap(fit2, n_boot = 499, seed = 42)
# print(boot)
# # $ci_lower / $ci_upper: named vectors covering gamma1, gamma2,
# #   regime1_x1, regime1_x2, regime2_x1, regime2_x2

## ----full_data_overview-------------------------------------------------------
data(panel_data)

cat("Countries :", length(unique(panel_data$country)), "\n")
cat("Years     :", min(panel_data$year), "–", max(panel_data$year), "\n")
cat("Obs       :", nrow(panel_data), "\n")
cat("Columns   :", ncol(panel_data), "\n")

# Both threshold variables and the dependent variable
summary(panel_data[, c("growthRate", "oilRentGDP", "rle", "eci")])

## ----full_fit2----------------------------------------------------------------
# Model I: oilRentGDP as threshold, rle as predictor
fit2_I <- bptr(
  growthRate ~ rle + eci + initialGDP + fdiGDP + capFormGDP +
               inflation + popGrowth + indVAGDP + tradeOpenness,
  data     = panel_data,
  id       = "countryId",
  time     = "year",
  q        = "oilRentGDP",
  n_thresh = 1,
  buffer   = TRUE,
  se_type  = "HC3"
)
print(fit2_I)

# Model II: rle as threshold, oilRentGDP as predictor
fit2_II <- bptr(
  growthRate ~ oilRentGDP + eci + initialGDP + fdiGDP + capFormGDP +
               inflation + popGrowth + indVAGDP + tradeOpenness,
  data     = panel_data,
  id       = "countryId",
  time     = "year",
  q        = "rle",
  n_thresh = 1,
  buffer   = TRUE,
  se_type  = "HC3"
)
print(fit2_II)

## ----full_seq, eval=FALSE-----------------------------------------------------
# # Model I: oilRentGDP as threshold, rle as predictor
# seq_I <- bptr_test_seq(
#   growthRate ~ rle + eci + initialGDP + fdiGDP + capFormGDP +
#                inflation + popGrowth + indVAGDP + tradeOpenness,
#   data        = panel_data,
#   id          = "countryId",
#   time        = "year",
#   q           = "oilRentGDP",
#   buffer      = TRUE,
#   n_boot      = 499,
#   grid_size_3 = 50,
#   alpha       = 0.10,
#   seed        = 2025
# )
# print(seq_I)
# 
# # Model II: rle as threshold, oilRentGDP as predictor
# seq_II <- bptr_test_seq(
#   growthRate ~ oilRentGDP + eci + initialGDP + fdiGDP + capFormGDP +
#                inflation + popGrowth + indVAGDP + tradeOpenness,
#   data        = panel_data,
#   id          = "countryId",
#   time        = "year",
#   q           = "rle",
#   buffer      = TRUE,
#   n_boot      = 499,
#   grid_size_3 = 50,
#   alpha       = 0.10,
#   seed        = 2025
# )
# print(seq_II)
# 
# # Fine-grid three-regime estimation for the selected model(s)
# fit3_I <- bptr(
#   growthRate ~ rle + eci + initialGDP + fdiGDP + capFormGDP +
#                inflation + popGrowth + indVAGDP + tradeOpenness,
#   data        = panel_data,
#   id          = "countryId", time = "year",
#   q           = "oilRentGDP",
#   n_thresh    = 2, buffer = TRUE, grid_size_3 = 80, se_type = "HC3"
# )
# summary(fit3_I)
# 
# fit3_II <- bptr(
#   growthRate ~ oilRentGDP + eci + initialGDP + fdiGDP + capFormGDP +
#                inflation + popGrowth + indVAGDP + tradeOpenness,
#   data        = panel_data,
#   id          = "countryId", time = "year",
#   q           = "rle",
#   n_thresh    = 2, buffer = TRUE, grid_size_3 = 80, se_type = "HC3"
# )
# summary(fit3_II)
# 
# # Bootstrap confidence intervals
# boot_I  <- bptr_bootstrap(fit2_I,  n_boot = 499, seed = 2025)
# boot_II <- bptr_bootstrap(fit2_II, n_boot = 499, seed = 2025)
# print(boot_I); print(boot_II)

## ----citation, eval=FALSE-----------------------------------------------------
# citation("bufferedThresholdPanel")

